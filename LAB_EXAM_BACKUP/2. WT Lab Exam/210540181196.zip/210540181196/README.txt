*****************************
Name= Shubham Ghosal
Batch-4
PRN No. = 210540181196
*****************************

I have uploaded the output screenshots according to the question folder that is Q1, Q2 and Q3. Please check the folder named "Output Screenshots" inside each of the question folders respectively.

I have also removed the unnecessary dependencies such as node_modules for the react application.

**********Thank You************