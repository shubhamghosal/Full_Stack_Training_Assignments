#!/bin/bash

#Script to print all files in home directory including hidden files

echo  "All files in home directory including hidden files are:"

ls -p | grep -v/))