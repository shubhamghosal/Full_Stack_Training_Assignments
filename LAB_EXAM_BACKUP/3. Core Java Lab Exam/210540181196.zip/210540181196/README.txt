*****************************
Name= Shubham Ghosal
Batch-4
PRN No. = 210540181196
*****************************

I have uploaded the output screenshots according to a different folder named "Output_Screenshots" and I have attached the designed code for book application in the "Codes" folder

To run the file kindly Bookshop from the "tester" package to see the required output.

Note: I have removed the unnecessary .metadata & Server folders from the code files to compress the folder in order to upload.


**********Thank You************