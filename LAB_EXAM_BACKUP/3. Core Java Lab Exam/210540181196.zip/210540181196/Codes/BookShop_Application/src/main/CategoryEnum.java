package main;

public enum CategoryEnum {
	TECHNOLOGY, FICTION, HEALTH, COMICS, SPORTS
}
